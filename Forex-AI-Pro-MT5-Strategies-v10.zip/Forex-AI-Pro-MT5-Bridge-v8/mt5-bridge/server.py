"""Read-only MT5 bridge for XAUUSD demo-account verification.
No order placement endpoints are implemented by design.
Run on the same Windows machine as the MetaTrader 5 terminal.
"""
import os
from datetime import datetime, timezone, timedelta
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

try:
    import MetaTrader5 as mt5
except ImportError:
    mt5 = None

app = FastAPI(title="Forex AI Pro MT5 Demo Auto-Trader", version="0.2.0")
origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "http://localhost:8000").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"])

class Quote(BaseModel):
    symbol: str
    bid: float
    ask: float
    last: float | None = None
    time_utc: str
    source: str = "MetaTrader 5 terminal"
    mode: str = "DEMO_READ_ONLY"


def terminal_or_503():
    if mt5 is None:
        raise HTTPException(503, "MetaTrader5 Python package is missing. Install requirements on Windows.")
    if not mt5.initialize():
        raise HTTPException(503, "MT5 terminal is not connected/initialized. Open MT5 and log into a DEMO account first.")
    account = mt5.account_info()
    if account is None:
        mt5.shutdown()
        raise HTTPException(503, "Cannot read MT5 account state.")
    # MetaTrader5 ACCOUNT_TRADE_MODE_DEMO is 0. Never expose live account data.
    if int(account.trade_mode) != 0:
        mt5.shutdown()
        raise HTTPException(403, "Safety lock: this bridge only serves DEMO accounts. Switch MT5 to a demo account.")
    return account

@app.get("/api/health")
def health():
    return {"ok": True, "service": "mt5-demo-auto-trader", "order_execution": os.getenv("DEMO_AUTO_TRADING_ENABLED", "false").lower() == "true", "utc": datetime.now(timezone.utc).isoformat()}

@app.get("/api/status")
def status():
    account = terminal_or_503()
    result = {"connected": True, "mode": "DEMO", "currency": str(account.currency), "balance": float(account.balance), "equity": float(account.equity), "order_execution": False}
    mt5.shutdown()
    return result

@app.get("/api/gold", response_model=Quote)
def gold():
    terminal_or_503()
    # Brokers often use suffixes/prefixes such as XAUUSD.a or GOLD; discover common variants.
    candidates = ["XAUUSD", "XAUUSD.", "XAUUSDm", "XAUUSD.a", "GOLD"]
    chosen = None
    for symbol in candidates:
        info = mt5.symbol_info(symbol)
        if info is not None:
            if not info.visible:
                mt5.symbol_select(symbol, True)
            tick = mt5.symbol_info_tick(symbol)
            if tick is not None and tick.bid > 0 and tick.ask >= tick.bid:
                chosen = (symbol, tick)
                break
    if chosen is None:
        all_symbols = mt5.symbols_get("*XAU*") or []
        names = [s.name for s in all_symbols[:20]]
        mt5.shutdown()
        raise HTTPException(404, "Gold symbol not found. Ask your broker's Market Watch symbol name. Candidates searched: XAUUSD/XAUUSDm/XAUUSD.a/GOLD. Found XAU symbols: " + ", ".join(names))
    symbol, tick = chosen
    payload = Quote(symbol=symbol, bid=float(tick.bid), ask=float(tick.ask), last=float(tick.last) if tick.last else None, time_utc=datetime.fromtimestamp(tick.time, timezone.utc).isoformat())
    mt5.shutdown()
    return payload

# Intentionally no POST endpoints and no order_send calls.


# DEMO-ONLY automated strategy. Disabled unless explicitly enabled in the local environment.
# Strategy: closed-candle EMA20/EMA50 trend + RSI filter, ATR-based stop and 2R target.
# This is an educational baseline, not a claim of profitability.
from fastapi import Body

@app.get("/api/strategy/status")
def strategy_status():
    return {
        "strategy": "Confluence: EMA20/50/200 + MACD + RSI + ADX + liquidity sweep/reclaim; ATR risk model",
        "mode": "DEMO_ONLY",
        "enabled": os.getenv("DEMO_AUTO_TRADING_ENABLED", "false").lower() == "true",
        "risk_percent": float(os.getenv("DEMO_RISK_PERCENT", "0.25")),
        "max_trades_per_day": int(os.getenv("DEMO_MAX_TRADES_PER_DAY", "3")),
        "reward_risk": 2.0,
        "indicators": ["EMA 20/50/200", "RSI 14", "MACD 12/26/9", "ADX 14", "ATR 14", "20-candle liquidity sweep/reclaim"],
        "minimum_confluence_score": 3,
        "note": "No strategy guarantees profits. Enable only on a DEMO account after testing."
    }

def _ema(values, period):
    alpha = 2.0 / (period + 1.0)
    result = values[0]
    for value in values[1:]:
        result = alpha * value + (1.0 - alpha) * result
    return result

def _rsi(values, period=14):
    changes = [values[i] - values[i-1] for i in range(1, len(values))]
    gains = sum(max(x, 0.0) for x in changes[-period:]) / period
    losses = sum(max(-x, 0.0) for x in changes[-period:]) / period
    if losses == 0:
        return 100.0
    return 100.0 - 100.0 / (1.0 + gains / losses)

def _atr(rates, period=14):
    trs = []
    for i in range(1, len(rates)):
        r, prev = rates[i], rates[i-1]
        trs.append(max(float(r['high']-r['low']), abs(float(r['high']-prev['close'])), abs(float(r['low']-prev['close']))))
    return sum(trs[-period:]) / period


def _macd_hist(values, fast=12, slow=26, signal=9):
    if len(values) < slow + signal + 2:
        return 0.0
    def ema_series(seq, period):
        alpha = 2.0 / (period + 1.0)
        out = [float(seq[0])]
        for v in seq[1:]:
            out.append(alpha * float(v) + (1.0-alpha) * out[-1])
        return out
    ef, es = ema_series(values, fast), ema_series(values, slow)
    macd = [a-b for a,b in zip(ef,es)]
    sig = ema_series(macd, signal)
    return macd[-1] - sig[-1]

def _adx(rates, period=14):
    if len(rates) < period * 2 + 2: return 0.0
    plus_dm=[]; minus_dm=[]; trs=[]
    for i in range(1,len(rates)):
        cur,prev=rates[i],rates[i-1]
        up=float(cur['high']-prev['high']); down=float(prev['low']-cur['low'])
        plus_dm.append(up if up>down and up>0 else 0.0)
        minus_dm.append(down if down>up and down>0 else 0.0)
        trs.append(max(float(cur['high']-cur['low']),abs(float(cur['high']-prev['close'])),abs(float(cur['low']-prev['close']))))
    dx=[]
    for i in range(period-1,len(trs)):
        tr=sum(trs[i-period+1:i+1])
        if tr<=0: continue
        pdi=100*sum(plus_dm[i-period+1:i+1])/tr; mdi=100*sum(minus_dm[i-period+1:i+1])/tr
        dx.append(100*abs(pdi-mdi)/(pdi+mdi) if pdi+mdi else 0.0)
    return sum(dx[-period:])/len(dx[-period:]) if dx else 0.0

def _strategy_snapshot(rates):
    # Closed candles only; no future data. Confluence is a filter, not a profitability claim.
    closed=rates[:-1]
    if len(closed)<220: raise HTTPException(503, "Need at least 220 closed candles for multi-indicator strategy")
    closes=[float(x['close']) for x in closed]
    fast=_ema(closes[-220:],20); mid=_ema(closes[-220:],50); long=_ema(closes[-220:],200)
    rsi=_rsi(closes,14); atr=_atr(closed,14); adx=_adx(closed,14); macd=_macd_hist(closes)
    recent=closed[-2]; prior=closed[-22:-2]
    prior_high=max(float(x['high']) for x in prior); prior_low=min(float(x['low']) for x in prior)
    # Liquidity sweep and reclaim: wick crosses prior range, close returns inside.
    sweep_bull=float(recent['low'])<prior_low and float(recent['close'])>prior_low
    sweep_bear=float(recent['high'])>prior_high and float(recent['close'])<prior_high
    bull=0; bear=0; reasons=[]
    if fast>mid>long: bull+=1; reasons.append("EMA20>EMA50>EMA200: اتجاه صاعد")
    elif fast<mid<long: bear+=1; reasons.append("EMA20<EMA50<EMA200: اتجاه هابط")
    if macd>0: bull+=1; reasons.append("MACD histogram موجب")
    elif macd<0: bear+=1; reasons.append("MACD histogram سالب")
    if 52<=rsi<=68: bull+=1; reasons.append("RSI يدعم الزخم الصاعد")
    elif 32<=rsi<=48: bear+=1; reasons.append("RSI يدعم الزخم الهابط")
    if adx>=20: reasons.append("ADX يؤكد وجود اتجاه نسبي")
    if sweep_bull: bull+=2; reasons.append("اكتشاف sweep هابط ثم استرداد المستوى")
    if sweep_bear: bear+=2; reasons.append("اكتشاف sweep صاعد ثم رفض المستوى")
    direction="BUY" if bull>=3 and bull>bear and adx>=18 else "SELL" if bear>=3 and bear>bull and adx>=18 else "NONE"
    return {"symbol":"XAUUSD","timeframe":os.getenv("MT5_TIMEFRAME","M15"),"mode":"ANALYSIS_ONLY","signal":direction,"confidence_score":max(bull,bear),"bull_score":bull,"bear_score":bear,"ema20":fast,"ema50":mid,"ema200":long,"rsi14":rsi,"macd_histogram":macd,"adx14":adx,"atr14":atr,"liquidity_sweep":{"bullish":sweep_bull,"bearish":sweep_bear},"reasons":reasons,"rule":"Confluence filter; not statistically validated; no guaranteed win rate"}

@app.get("/api/strategy/analyze")
def strategy_analyze():
    terminal_or_503()
    symbol,_info=_find_gold_symbol()
    tfname=os.getenv("MT5_TIMEFRAME","M15").upper()
    tf={"M5":mt5.TIMEFRAME_M5,"M15":mt5.TIMEFRAME_M15,"M30":mt5.TIMEFRAME_M30,"H1":mt5.TIMEFRAME_H1}.get(tfname)
    if tf is None: mt5.shutdown(); raise HTTPException(400,"MT5_TIMEFRAME must be M5, M15, M30 or H1")
    rates=mt5.copy_rates_from_pos(symbol,tf,0,260)
    if rates is None or len(rates)<222: mt5.shutdown(); raise HTTPException(503,"Not enough MT5 candles")
    result=_strategy_snapshot(rates); result["symbol"]=symbol
    mt5.shutdown()
    return result

def _find_gold_symbol():
    candidates = [os.getenv("MT5_GOLD_SYMBOL", "XAUUSD"), "XAUUSD", "XAUUSDm", "XAUUSD.a", "GOLD"]
    for name in dict.fromkeys(candidates):
        info = mt5.symbol_info(name)
        if info is not None:
            if not info.visible:
                mt5.symbol_select(name, True)
            return name, info
    found = mt5.symbols_get("*XAU*") or []
    raise HTTPException(404, "Gold symbol not found: " + ", ".join(x.name for x in found[:20]))

@app.post("/api/auto-trade/demo-cycle")
def demo_auto_trade_cycle(confirm_demo: bool = Body(default=False, embed=True)):
    """Run one evaluation cycle. Orders are possible only on DEMO and only when explicitly enabled."""
    if os.getenv("DEMO_AUTO_TRADING_ENABLED", "false").lower() != "true":
        raise HTTPException(423, "Trading is disabled. Set DEMO_AUTO_TRADING_ENABLED=true locally after reading the safety instructions.")
    if not confirm_demo:
        raise HTTPException(400, "Explicit DEMO confirmation required: send {\"confirm_demo\": true}.")
    account = terminal_or_503()  # hard-rejects non-demo accounts
    if int(account.trade_mode) != 0:
        raise HTTPException(403, "Safety lock: DEMO accounts only.")
    symbol, info = _find_gold_symbol()
    timeframe_name = os.getenv("MT5_TIMEFRAME", "M15").upper()
    timeframe = {"M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1}.get(timeframe_name)
    if timeframe is None:
        raise HTTPException(400, "MT5_TIMEFRAME must be M5, M15, M30 or H1")
    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, 260)
    if rates is None or len(rates) < 222:
        raise HTTPException(503, "Not enough candles from MT5")
    # Drop the currently forming candle to avoid using incomplete data.
    closed = rates[:-1]
    closes = [float(x['close']) for x in closed]
    fast, slow = _ema(closes[-80:], 20), _ema(closes[-80:], 50)
    rsi = _rsi(closes, 14)
    atr = _atr(closed, 14)
    tick = mt5.symbol_info_tick(symbol)
    if tick is None or atr <= 0:
        raise HTTPException(503, "No valid tick/ATR")
    max_spread_atr = float(os.getenv("DEMO_MAX_SPREAD_ATR", "0.15"))
    spread = float(tick.ask - tick.bid)
    if spread > atr * max_spread_atr:
        mt5.shutdown()
        return {"status":"skipped", "reason":"Spread too large relative to ATR", "spread":spread, "atr":atr}
    positions = mt5.positions_get(symbol=symbol) or []
    if positions:
        mt5.shutdown()
        return {"status":"skipped", "reason":"An open position already exists for gold; no stacking", "symbol":symbol}
    now = datetime.now(timezone.utc)
    start_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
    deals = mt5.history_deals_get(start_day, now) or []
    today_entries = [d for d in deals if getattr(d, 'symbol', '') == symbol and getattr(d, 'entry', -1) == mt5.DEAL_ENTRY_IN]
    max_daily = int(os.getenv("DEMO_MAX_TRADES_PER_DAY", "3"))
    if len(today_entries) >= max_daily:
        mt5.shutdown()
        return {"status":"locked", "reason":"Daily trade limit reached", "trades_today":len(today_entries)}
    snapshot = _strategy_snapshot(rates)
    direction = snapshot["signal"]
    if direction == "NONE":
        mt5.shutdown()
        return {"status":"no_signal", "symbol":symbol, "analysis":snapshot, "message":"Confluence threshold not met; no trade opened."}
    risk_pct = min(max(float(os.getenv("DEMO_RISK_PERCENT", "0.25")), 0.01), 0.5)
    risk_money = float(account.equity) * risk_pct / 100.0
    entry = float(tick.ask if direction == "BUY" else tick.bid)
    stop_distance = 1.5 * atr
    stop = entry - stop_distance if direction == "BUY" else entry + stop_distance
    target = entry + 2.0 * stop_distance if direction == "BUY" else entry - 2.0 * stop_distance
    # Estimate lot size from tick value and tick size; refuse if broker metadata is incomplete.
    if not info.trade_tick_size or not info.trade_tick_value:
        mt5.shutdown()
        raise HTTPException(503, "Broker does not provide valid tick size/value; refusing to size a trade")
    loss_per_lot = (stop_distance / float(info.trade_tick_size)) * float(info.trade_tick_value)
    if loss_per_lot <= 0:
        mt5.shutdown()
        raise HTTPException(503, "Invalid risk calculation; refusing trade")
    raw_volume = risk_money / loss_per_lot
    step = float(info.volume_step or 0.01)
    volume = (raw_volume // step) * step
    volume = round(volume, 8)
    if volume < float(info.volume_min) or volume > float(info.volume_max):
        mt5.shutdown()
        return {"status":"skipped", "reason":"Calculated lot size outside broker limits", "calculated_volume":volume, "risk_money":risk_money}
    request = {"action":mt5.TRADE_ACTION_DEAL,"symbol":symbol,"volume":volume,"type":mt5.ORDER_TYPE_BUY if direction == "BUY" else mt5.ORDER_TYPE_SELL,"price":entry,"sl":round(stop, info.digits),"tp":round(target, info.digits),"deviation":int(os.getenv("DEMO_DEVIATION_POINTS","30")),"magic":20261023,"comment":"ForexAI DEMO CONFLUENCE","type_time":mt5.ORDER_TIME_GTC,"type_filling":info.filling_mode}
    check = mt5.order_check(request)
    if check is None or check.retcode not in (0, mt5.TRADE_RETCODE_DONE):
        mt5.shutdown()
        return {"status":"check_failed", "reason":str(getattr(check,'comment','order_check failed')), "retcode":getattr(check,'retcode',None), "signal":direction}
    result = mt5.order_send(request)
    mt5.shutdown()
    if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
        return {"status":"order_failed", "retcode":getattr(result,'retcode',None), "comment":getattr(result,'comment','order_send failed')}
    return {"status":"demo_order_sent", "symbol":symbol, "direction":direction, "volume":volume, "entry":entry, "sl":round(stop,info.digits), "tp":round(target,info.digits), "risk_percent":risk_pct, "rsi14":round(rsi,2), "ema20":fast, "ema50":slow, "analysis":snapshot, "ticket":result.order, "mode":"DEMO"}
